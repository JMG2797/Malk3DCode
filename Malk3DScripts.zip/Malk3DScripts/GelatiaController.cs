﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GelatiaController : MonoBehaviour
{
    public GameObject gelatinaBullet;
    public GameObject socket;
    public GameObject Teleport;
    public float health;
    public GameObject bossUI;
    public GameObject explosion;
    public Slider healthSlider;
    public float speed = 6f;
    public float attackRate = 2f;
    private float attackCounter = 0f;
    public float attackRange;
    private float howClose;
    public Animator gelAnim;
    Transform player;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        gelAnim = GetComponent<Animator>();
        bossUI.SetActive(true);
        Teleport.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        SetUI();

        transform.LookAt(player);

        if (attackCounter <= 0f)
         {
           Shoot();
           attackCounter = 1f / attackRate;
         }
        attackCounter -= Time.deltaTime;


    }

    void Shoot()
    {
        Instantiate(gelatinaBullet, socket.transform.position, socket.transform.rotation);
    }

    void SetUI()
    {
        healthSlider.value = health;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("PlayerBullet"))
        {
            health -= 15;
            Destroy(other.gameObject);
            SetUI();
            if(health <= 0)
            {
                Instantiate(explosion, transform.position, transform.rotation);
                Destroy(this.gameObject);
                bossUI.SetActive(false);
                Teleport.SetActive(true);
            }
        }

        if(other.CompareTag("DeathZone"))
        {
            Destroy(this.gameObject);
            bossUI.SetActive(false);
            Teleport.SetActive(true);
        }
    }
}
