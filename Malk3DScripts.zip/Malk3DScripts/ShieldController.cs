﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldController : MonoBehaviour
{
    public GameObject Shield;
    private PlayerController player;
   // public bool activeShield;


    public void Start()
    {
       // activeShield = false;
        //Shield.SetActive(false);
    }


    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.F) && PlayerController.playerEnergy >= 10 && player.isGrounded == true)
        {

            Debug.Log("Shield Instantiated");
            //Shield.SetActive(true);
            //activeShield = true;
            Instantiate(gameObject, player.transform.position, Quaternion.identity);
            PlayerController.playerEnergy = PlayerController.playerEnergy - 10;
            player.SetUI();
            Destroy(gameObject, 10f);

           /* if (activeShield == false)
            {
                Debug.Log("Shield Instantiated");
                Shield.SetActive(true);
                activeShield = true;
                Instantiate(gameObject, player.transform.position, Quaternion.identity);
                player.playerEnergy = player.playerEnergy - 10;
                player.SetUI();
                Destroy(gameObject, 10f);


            }*/
        }
    }
           /* else
            {
                Shield.SetActive(false);
                activeShield = false;
            }
        }
    }

    public bool ActiveShield
    {
        get
        {
            return activeShield;
        }

        set
        {
            activeShield = value;
        }
    }
           */

    private void OnTriggerEnter(Collider ObjCollision)
    {
        if(ObjCollision.tag == "EnemyBullet" || ObjCollision.tag == "Enemy" ||
            ObjCollision.tag == "Enemy2" || ObjCollision.tag == "Pinguino"
            || ObjCollision.tag == "Cactus" || ObjCollision.tag == "Cebolla"||
            ObjCollision.tag == "ZanahoriaBullet" || ObjCollision.tag == "MariposaLaser"
            || ObjCollision.tag == "Malvavisco")
        {
            Destroy(ObjCollision.transform.parent.gameObject);
        }
    }
}
