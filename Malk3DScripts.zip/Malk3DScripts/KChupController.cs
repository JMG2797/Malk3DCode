﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KChupController : MonoBehaviour
{
    public GameObject explosion;
    public List<GameObject> Points;
    private int CurrentPoint;
    public Animator EnemyAnim;
    public float Enemy1Speed;

    void Start()
    {
        EnemyAnim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, Points[CurrentPoint].
            transform.position, Enemy1Speed * Time.deltaTime);

        if (transform.position == Points[CurrentPoint].transform.position)
        {
            //EnemyAnim.SetBool("Walking", true);
            CurrentPoint++;
            if (CurrentPoint >= Points.Count)
            {
                CurrentPoint = 0;
            }
            Vector3 NewDir = Points[CurrentPoint].transform.position - transform.position;
            NewDir.y = 0;

            if (NewDir != Vector3.zero)
            {
                transform.rotation = Quaternion.LookRotation(NewDir);
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}
