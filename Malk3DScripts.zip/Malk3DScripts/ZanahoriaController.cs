﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ZanahoriaController : MonoBehaviour
{
    public GameObject spawnBulletPoint;
    public float timeToTeleport = 8f;
    private float nextTeleport;
    //public List<GameObject> TeleportPoints;
    Transform player;
    public GameObject ZanahoriaBullet;
    public float fireRate = 2f;
    private float nextFireTime;
    public float health = 450f;
    public Slider healthSlider;


    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        Teleport();
        ShootPlayer();
        SetUI();
    }

    void Teleport()
    {
        if(nextTeleport <= Time.time)
        {
            nextTeleport = Time.time + timeToTeleport;
        }
    }

    void ShootPlayer()
    {
        transform.LookAt(player);
        if (nextFireTime <= Time.time)
        {
            GameObject bullet = Instantiate(ZanahoriaBullet);
            bullet.transform.position = spawnBulletPoint.transform.position;
            bullet.transform.forward = spawnBulletPoint.transform.forward;
            nextFireTime = Time.time + fireRate;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag ("PlayerBullet"))
        {
            health -= 15;
            SetUI();
        }
    }

    void SetUI()
    {
        healthSlider.value = health;
    }
}
