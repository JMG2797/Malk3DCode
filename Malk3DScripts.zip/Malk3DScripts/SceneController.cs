﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneController : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene(4);
        PlayerController.playerHealth = 100f;
        PlayerController.playerEnergy = 100f;
        PlayerController.playerAmmo = 30;
    }

    public void OptionsMenu()
    {
        SceneManager.LoadScene(2);
    }

    public void ExitApp()
    {
        Debug.Log("Exited the App");
        Application.Quit();
    }

    public void returntomenu()
    {
        SceneManager.LoadScene(1);
    }
}
