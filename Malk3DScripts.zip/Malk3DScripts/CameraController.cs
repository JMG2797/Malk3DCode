﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    [Header("Camera Stats")]

    public float cameraSpeed,  DistZ, Height;
    public float rotationSpeed;

    public GameObject Target, TempRot;



    
    void Start()
    {
        
    }

   
    void Update()
    {
       if (!Target)
            return;

        transform.position = Vector3.Lerp(transform.position, 
            new Vector3(Target.transform.position.x, Target.transform.position.y + Height,
            Target.transform.position.z -DistZ), cameraSpeed* Time.deltaTime);

        TempRot.transform.LookAt(Target.transform);
        transform.rotation = Quaternion.Lerp(transform.rotation, TempRot.transform.rotation,
            rotationSpeed*Time.deltaTime);


    }
}
