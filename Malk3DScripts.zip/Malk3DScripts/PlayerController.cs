﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    [Header("Player Stats")]

    public float            playerSpeed;
    static public float     playerHealth = 100f;
    public float            playerJumpSpeed = 100f;
    public int              JumpCount;
    public int              TotalJumps;
    static public float     playerEnergy = 100f;
    public int              Lives = 3;
    static public int       playerAmmo = 30;
    public float            RadAttack;
    public float            RateAttack;
    public float            TimeAttack;
    public float            ShieldTime;

    [Header("Enviorement Stats")]
    public float Gravity;
    //public List<GameObject> CheckPoints;

    [Header("Dash")]
    public float dashSpeed;
    public float dashTime;
    PlayerController player;

    //Private Varaibles
    private CharacterController Control;
    private Vector3 moveDir = Vector3.zero;
    private List<Collider> EnemiesOverlap = new List<Collider>();
    private RaycastHit HitFoot;
    private BulletController Bullet;


    [Header("Public Objects")]

    public GameObject   PlayerBullet;
    public GameObject   playerShield;
    public Slider       EnergySlider;
    public Slider       HealthSlider;
    public Text         AmmoText;
    public GameObject   Socket;
    public Text         PlayerLives;
    public GameObject   PauseMenu;
    public GameObject   InGameMenu;
    public GameObject   StartPoint;
    public GameObject   Checkpoint;
    public Animator     MalkAnim;
    

    [Header("ParticleSystems")]
    public GameObject RadiusExplosion;
    //public GameObject EnemyExplosion;

    [Header("States")]
    public bool  isMoving;
    public bool  isGrounded;
    public bool  isColliding;
    public bool  isDashing;
    public bool  extraJump;
    public bool  isAttacking;
    private bool ActiveRadiusAttack;
    private bool CardRecol;
    public bool  Checkpointed;
    public bool  AtStartPoint;

    [Header("Recolections")]
    public bool tarjeta1;
    public bool tarjeta2;
    public bool tarjeta3;
    public bool tarjeta4;
    public bool batallaFinal;
    //public GameObject teleportFinal;

    //ReferenciasOtros
    ReyGorgonzollaController RGControl;
    private BossController Boss;
    private GelatiaController gealtinaCont;
    private MuelaController muelaCont;
    private VacaController vacaCont;
    private MariposaController mariposaCont;

    [Header("Sounds")]
    public float soundVolume;
    public AudioSource dashAS;
    public AudioClip dashAC;
    public AudioSource jumpAS;
    public AudioClip jumpAC;
    public AudioSource areaAS;
    public AudioClip areaAC;
    public AudioSource recAS;
    public AudioClip recAC;

    void Start()
    {
        Control = GetComponent<CharacterController>();
        playerShield.SetActive(false);
        SetUI();
        AtStartPoint = true;
        Checkpointed = false;
        CardRecol = false;
        player = GetComponent<PlayerController>();
        //Recharge();
    }

   
    void Update()
    {
        PlayerMovement();
        AttackSystem();
        GetDamage();
        PauseGame();
        Shoot();
        SetUI();
        CreateShield();
        if(Input.GetKeyDown(KeyCode.T) && playerEnergy >= 15) 
        {
            StartCoroutine(Dash());
            dashAS.PlayOneShot(dashAC, soundVolume);
            playerEnergy -= 15;
        }

        if (Lives <= 0)
        {
            SceneManager.LoadScene(15);
        }
    }

    private void PlayerMovement()
    {
        if(Control.isGrounded)
        {
            MalkAnim.SetBool("IsGrounded", true);
            JumpCount = 0;
            
            moveDir = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
            //moveDir = transform.TransformDirection(moveDir); //En caso de que queramos que el personaje gire el vector Z al girar. Movimiento Local
            moveDir *= playerSpeed;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                //MovDir = new Vector3(Input.GetAxis("Horizontal") * playerSpeed, MovDir.y, Input.GetAxis("Horizontal") * playerSpeed);
                MalkAnim.SetBool("IsGrounded", false);
                moveDir.y = playerJumpSpeed;
                extraJump = true;
                jumpAS.PlayOneShot(jumpAC,soundVolume);
            }

            MalkAnim.SetFloat("Speed", Mathf.Abs
               (Input.GetAxis("Horizontal") + Input.GetAxis("Vertical")));
        }

        else
        {
            moveDir = new Vector3(Input.GetAxis("Horizontal") * playerSpeed, moveDir.y, Input.GetAxis("Vertical") * playerSpeed);

            

            if (Input.GetKeyDown(KeyCode.Space) && JumpCount < TotalJumps)
            {
               //MovDir = new Vector3(Input.GetAxis("Horizontal") * playerSpeed, MovDir.y, Input.GetAxis("Horizontal") * playerSpeed);
                moveDir.y = playerJumpSpeed;
                JumpCount++;
            }
        }
         
        Vector3 NewDir = moveDir;
        NewDir.y = 0;
        if (NewDir != Vector3.zero)
        {
            if (moveDir.x != 0 || moveDir.z !=0 )
            {
                transform.rotation = Quaternion.LookRotation(NewDir);
            }
        }

        moveDir.y -= Gravity * Time.deltaTime;
        Control.Move(moveDir * Time.deltaTime);

      
    }

    IEnumerator Dash()
    {
        float startTime = Time.time;
        while(Time.time < startTime + dashTime)
        {
            player.Control.Move(player.moveDir * dashSpeed * Time.deltaTime);

            yield return null;
        }
    }

    private void Shoot()
    {
        if (Input.GetKeyDown(KeyCode.Q) && playerAmmo >= 1)
        {
            GameObject bulletObject = Instantiate(PlayerBullet);
            bulletObject.transform.position = Socket.transform.position + Socket.transform.forward;
            bulletObject.transform.forward = Socket.transform.forward;
            playerAmmo--;
            SetUI();
        }
    }

    private void AttackSystem()      
    {
        if (Physics.Raycast(transform.position, Vector3.down, out HitFoot, 1.5f))
        {
            if (HitFoot.collider.tag == "Enemy" || HitFoot.collider.tag == "Enemy2" ||
                HitFoot.collider.tag == "Cebolla" || HitFoot.collider.tag == "Robot" ||
                HitFoot.collider.tag == "Cactus" ||  HitFoot.collider.tag == "Pinguino"
                || HitFoot.collider.tag == "Kchup" || HitFoot.collider.tag == "Macaco"
                || HitFoot.collider.tag == "Malvavisco" || HitFoot.collider.tag == "Coal")
            {
                Destroy(HitFoot.collider.gameObject);
                moveDir.y = playerJumpSpeed;
            }

        }

        if (ActiveRadiusAttack == true)
        {
            EnemiesOverlap = new List<Collider>(Physics.OverlapSphere
                (transform.position, RadAttack));
            for(int i = 0; i<EnemiesOverlap.Count; i++)
            {
                if (EnemiesOverlap [i].tag == "Enemy" || EnemiesOverlap[i].tag == "Enemy2"
                    || EnemiesOverlap[i].tag == "Cactus" || EnemiesOverlap[i].tag == "Robot"
                    || EnemiesOverlap[i].tag == "Pinguino" || EnemiesOverlap[i].tag == "Cebolla"
                    || EnemiesOverlap[i].tag == "Macaco" || EnemiesOverlap[i].tag == "Malvavisco"
                    || EnemiesOverlap[i].tag == "Kchup" || EnemiesOverlap[i].tag == "Coal")
                {
                    Destroy(EnemiesOverlap[i].gameObject);
                }

                if (EnemiesOverlap[i].tag == "ReyGorgonzolla")
                {
                    RGControl.bossHealth -=25;
                }
                if (EnemiesOverlap[i].tag == "Hellatina")
                {
                    gealtinaCont.health -= 25;
                }
                if (EnemiesOverlap[i].tag == "Vaca")
                {
                    vacaCont.health -= 25;
                }
                if (EnemiesOverlap[i].tag == "Muela")
                {
                    muelaCont.health -= 25;
                }
                if (EnemiesOverlap[i].tag == "Mariposa")
                {
                    gealtinaCont.health -= 25;
                }
            }
        }
        else
        {
            RateAttack += Time.deltaTime;
            if (RateAttack >= 0.5f && Input.GetKeyDown(KeyCode.E) && playerEnergy >= 10)
            {
                playerEnergy = playerEnergy - 10;
                SetUI();
                RateAttack = 0;
                Instantiate(RadiusExplosion, transform.position, Quaternion.identity);
                areaAS.PlayOneShot(areaAC, soundVolume);
                ActiveRadiusAttack = true;
                Invoke("StopAttack", 0.5f);
            }
        }

       
    }

    private void StopAttack()
    {
        ActiveRadiusAttack = false;
        EnemiesOverlap.Clear();
    }
    
    private void GetDamage()
        
    {
            
        if (playerHealth <= 0)
        {
            Lives -= 1;
            SetUI();

            if (AtStartPoint == true & Checkpointed == false)
            {
                transform.position = StartPoint.transform.position;
            }
            else if (AtStartPoint == false && Checkpointed ==true)
            {
                transform.position = Checkpoint.transform.position;
            }
            SetUI();

            if (Lives <= 0)
            {   
                SceneManager.LoadScene(15);
                Invoke("Recharge", 1f);
                SetUI();
            }

        }
        
    }


    public void SetUI()
    {
        HealthSlider.value = playerHealth;
        EnergySlider.value = playerEnergy;
        AmmoText.text           = "" + playerAmmo;
        PlayerLives.text        = "" + Lives;
    }
        
    private void PauseGame()
        
    {
          if (Input.GetKeyDown(KeyCode.Escape))
        {
            InGameMenu.SetActive(false);
            PauseMenu.SetActive(true);
            Time.timeScale = 0;
        }
    }

    public void ResumeGame()
    {
        PauseMenu.SetActive(false);
        InGameMenu.SetActive(true);
        Time.timeScale = 1;
    }

    public void ExitPlay()
    {
        SceneManager.LoadScene(1);
        Time.timeScale = 1;
    }

    public void CreateShield()
    {
        if (Input.GetKeyDown(KeyCode.R) && playerEnergy >= 10 && Control.isGrounded)
        {
            playerShield.SetActive(true);
            playerEnergy = playerEnergy - 10f;
            playerHealth += 15;
            SetUI();
            Invoke("DeactivateShield", 3f);
        }

    }
        
    private void OnTriggerEnter(Collider ObjCollision)
        
    {
            
        if (ObjCollision.CompareTag("DeathZone"))            
        {
            if (AtStartPoint == true & Checkpointed == false)
            {
                transform.position = StartPoint.transform.position;
            }
            else if (AtStartPoint == false && Checkpointed == true)
            {
                transform.position = StartPoint.transform.position;
            }
            
            Lives--;
            SetUI();
           
        }

        if (ObjCollision.CompareTag("FinalTeleport"))
        {
            SceneManager.LoadScene(13);
        }

        if (ObjCollision.CompareTag("Teleport") && CardRecol == true)
        {
            SceneManager.LoadScene(12);
        }

        if (ObjCollision.CompareTag("FallHub"))
        {
            transform.position = StartPoint.transform.position;
        }

           
        if (ObjCollision.CompareTag("Energyitem"))          
        {
            
            playerEnergy = playerEnergy + 15;
            Destroy(ObjCollision.gameObject);
            recAS.PlayOneShot(recAC, soundVolume);
            if (playerEnergy > 100)
            {
                playerEnergy = 100;
            }
            SetUI();
        }

        if (ObjCollision.CompareTag("BulletItem"))
        {
            playerAmmo = playerAmmo + 10;  
            Destroy(ObjCollision.gameObject);
            recAS.PlayOneShot(recAC, soundVolume);
            if(playerAmmo >= 100)
            {
                playerAmmo = 100;
            }
            SetUI();
        }

        if (ObjCollision.CompareTag("HealthItem"))
        {
            
            playerHealth = playerHealth + 25;
            Destroy(ObjCollision.gameObject);
            recAS.PlayOneShot(recAC, soundVolume);
            if (playerHealth > 100)
            {
                playerHealth = 100;
            }
            SetUI();
        }

        if (ObjCollision.CompareTag("Enemy"))
        {
            
            playerHealth = playerHealth - 15;
            //Destroy(ObjCollision.gameObject);
            SetUI();
           
        }

        if (ObjCollision.CompareTag("Enemy2"))
        {
            
            playerHealth = playerHealth - 25;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Pinguino"))
        {

            playerHealth = playerHealth - 25;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Cactus"))
        {

            playerHealth = playerHealth - 20;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Cebolla"))
        {

            playerHealth = playerHealth - 25;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Robot"))
        {

            playerHealth = playerHealth - 15;
            SetUI();

        }
        if (ObjCollision.CompareTag("Kchup"))
        {

            playerHealth = playerHealth - 20;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Malvavisco"))
        {

            playerHealth = playerHealth - 25;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }
        if (ObjCollision.CompareTag("Coal"))
        {

            playerHealth = playerHealth - 25;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.CompareTag("Macaco"))
        {

            playerHealth = playerHealth - 10;
            //Destroy(ObjCollision.gameObject);
            SetUI();

        }

        if (ObjCollision.tag == "Card")
        {
            CardRecol = true;
            Destroy(ObjCollision.gameObject);
        }


        if (ObjCollision.tag == "CheckPoint")
        {
            AtStartPoint = false;
            Checkpointed = true;
        }

        if (ObjCollision.tag == "Boss")
        {
            playerHealth = playerHealth - 15;
            SetUI();
    
        }

        if (ObjCollision.tag == "ReyGorgonzolla")
        {
            playerHealth = playerHealth - 30;
            playerEnergy -= 30;
            SetUI();

        }

        if (ObjCollision.CompareTag("EnemyBullet"))
        {
            playerHealth = playerHealth - 15;
            SetUI();
        }

        if(ObjCollision.CompareTag("ZanahoriaBullet"))
        {
            playerHealth -= 25;
            SetUI();
        }

        if (ObjCollision.CompareTag("Mariposa"))
        {
            playerHealth -= 25;
            SetUI();
        }

        if (ObjCollision.CompareTag("Vaca"))
        {
            playerHealth -= 25;
            SetUI();
        }

        if (ObjCollision.CompareTag("MariposaLaser"))
        {
            playerHealth -= 25;
            SetUI();
        }
        if (ObjCollision.CompareTag("Hellatina"))
        {
            playerHealth -= 25;
            SetUI();
        }

        if (ObjCollision.CompareTag("Muela"))
        {
            playerHealth -= 40;
            SetUI();
        }

        if (ObjCollision.tag == "EndPoint")
        {
            SceneManager.LoadScene(4);
        }


        if (ObjCollision.CompareTag("FinalTeleport"))
        {
            //SceneManager.LoadScene("");
        }

        /*if(ObjCollision.CompareTag("ZanahoriaChip"))
        {
            tarjeta1 = true;
            Destroy(ObjCollision.gameObject);
        }*/

    }

    public void DeactivateShield()
    {
        playerShield.SetActive(false);
    }

    public void AllowFinalBattle()
    {
        if(tarjeta1==true && tarjeta2 == true && tarjeta3 == true && tarjeta4 == true)
        {
            batallaFinal = true;

            /*if(batallaFinal == true)
            {
                teleportFinal.SetActive(true);
            }*/
        }

    }

    public void Recharge()
    {
        playerHealth = 100f;
        playerEnergy = 100f;
        playerAmmo = 30;
    }

}
