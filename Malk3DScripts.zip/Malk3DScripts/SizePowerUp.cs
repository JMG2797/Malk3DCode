﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
public class SizePowerUp : MonoBehaviour
{
    public float SizeMultiplier = 2f;
    public float duration = 6f;
    public GameObject SizePowerUpEffect;
    //private PlayerController player;
    public AudioSource PUAS;
    public AudioClip PUAC;
    public float volume;

    private void OnTriggerEnter(Collider ObjCollision)
    {
        if (ObjCollision.tag == "Player")
        {
            StartCoroutine(PickUp(ObjCollision));
        }
    }

    IEnumerator PickUp(Collider Player)
    {
        Instantiate(SizePowerUpEffect, transform.position, transform.rotation);
        PUAS.PlayOneShot(PUAC, volume);
        Player.transform.localScale *= SizeMultiplier;
        //player.playerHealth *= 2;

        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        //Wait x amount of seconds
        yield return new WaitForSeconds(5f);
        //player.playerHealth /= 2;
        Player.transform.localScale /= SizeMultiplier;

        Destroy(gameObject);
        Debug.Log("Power Up Recogido");
    }
}
