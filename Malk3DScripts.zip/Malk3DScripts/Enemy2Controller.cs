﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy2Controller : MonoBehaviour
{
    private CharacterController     control;
    private Vector3 MovDir =        Vector3.zero;
    public float                    Speed, Gravity, JumpSpeed;
    public List<GameObject>         Points;
    private int                     CurrentPoint;
    public Animator Enemy2Anim;
    private float TimeJump;
    private float DistancePoint;
    public GameObject explosion;

    void Start()
    {
        control = GetComponent<CharacterController>();
    }

 
    void Update()
    {
        
        if(control.isGrounded)
        {
            Enemy2Anim.SetFloat("Speed", Mathf.Abs
             (Input.GetAxis("Horizontal") + Input.GetAxis("Vertical")));
            DistancePoint = Vector3.Distance(transform.position, Points[CurrentPoint].transform.position);

            if (DistancePoint < 2)
            {
                CurrentPoint++;
                if (CurrentPoint >= Points.Count)
                {
                    CurrentPoint = 0;
                }

            }

                TimeJump += Time.deltaTime;
            if (TimeJump >= 1f)
            {
               

                    TimeJump = 0;
                MovDir.y = JumpSpeed;

                Vector3 NewDir = Points[CurrentPoint].transform.position - transform.position;
                NewDir.y = 0;
                if(NewDir != Vector3.zero)
                {
                    transform.rotation = Quaternion.LookRotation(NewDir);
                }
            }

            
            
        }
        else
        {
            
            
            transform.position = Vector3.MoveTowards(transform.position,
                Points[CurrentPoint].transform.position, Speed * Time.deltaTime);

        }

        MovDir.y -= Gravity * Time.deltaTime;
        control.Move(MovDir * Time.deltaTime);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}
