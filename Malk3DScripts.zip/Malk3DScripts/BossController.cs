﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;

public class BossController : MonoBehaviour
{
    public float bossHealth = 500f;
    public float StoppingDistance;
    public float RetreatDistance;
    public float timeBtwShots;
    private float StartTimeBtwShots;
    //public float Speed;
    public Slider BossHealth;
    public Animator BossAnim;
    public bool SecondPhase; 
    public GameObject BossUI;
    public GameObject explosion;
    public PlayerController player;
    private Vector3 BossMoveDir;
    public GameObject Target;
    public GameObject Socket;
   // public float playerDist;
    public GameObject EnemyBullet;
    public GameObject EndPoint;
    void Start()
    {
        SecondPhase = false;
        timeBtwShots = StartTimeBtwShots;
        EndPoint.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        /*playerDist = Vector3.Distance(player.transform.position, transform.position);
        if (playerDist <= 2f)
        {
            // Attack();
        }*/

        SetUI();
        Movement();      
        Phase2();
    }
    

    public void OnTriggerEnter(Collider ObjCollision)
    {
        if (ObjCollision.tag == "PlayerBullet")
        {
            bossHealth = bossHealth - 10;
            if (bossHealth <= 0)
            {           
                Instantiate(explosion, transform.position, transform.rotation);
                Destroy(this.gameObject);
                bossHealth = 0;
                SetUI();
                BossUI.SetActive(false);
                //SceneManager.LoadScene(4);
                EndPoint.SetActive(true);
            }
        }

        if (ObjCollision.tag == "Deathzone")
        {
            //SceneManager.LoadScene(4);
            Destroy(this.gameObject);
            bossHealth = 0;
            SetUI();
            BossUI.SetActive(false);
            EndPoint.SetActive(true);
        }

        if (ObjCollision.tag == "Shield")
        {
            bossHealth = bossHealth - 25;
            player.playerShield.SetActive(false);
            SetUI();
        }
    }

    void Movement()
    {
        transform.position = Vector3.MoveTowards(transform.position, Target.transform.position,
            9f * Time.deltaTime);

        Vector3 NewDir = Target.transform.position - transform.position;
        NewDir.y = 0;
        if (NewDir != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(NewDir);
        }


    }

    /*public void Attack()
    {
        BossAnim.SetBool("IsAttacking", true);
        //GameObject bulletObject = Instantiate(EnemyBullet);
        //bulletObject.transform.position = Socket.transform.position + Socket.transform.forward;
        //bulletObject.transform.forward = Socket.transform.forward;
        if(timeBtwShots <= 5f)
        {
            Instantiate(EnemyBullet,Socket.transform.position,Quaternion.identity);
            timeBtwShots = StartTimeBtwShots;
        }
    }*/

    public void SetUI()
    {
        BossHealth.value = bossHealth;
    }

    public void Phase2()
    {
        if (bossHealth <= 200)
        {
            SecondPhase = true;
            if (SecondPhase == true)
            {
                bossHealth = bossHealth + 5 * Time.deltaTime;
                SetUI();
            }
        }
        else
        {
            SecondPhase = false;
        }

        
    }
}
