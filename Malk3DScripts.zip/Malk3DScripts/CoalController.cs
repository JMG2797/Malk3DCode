﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoalController : MonoBehaviour
{
    Transform player;
    public Animator anim;
    public Rigidbody rb;
    public float attackRange;
    private float howClose;
    public float speed;
    public GameObject explosion;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        howClose = Vector3.Distance(transform.position, player.position);
        
        if(howClose >= attackRange)
        {
            anim.SetBool("Attacking", false);
            anim.SetFloat("Speed", 0);
        }


        else if(howClose <= attackRange)
        {
            anim.SetFloat("Speed", 1);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position, speed * Time.deltaTime);

            if(howClose <= 1f)
            {
                anim.SetBool("Attacking", true);
            }

        }

    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("PlayerBullet"))
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }

        if (other.CompareTag("Shield"))
        {
            Destroy(this.gameObject);
        }
    }

}
