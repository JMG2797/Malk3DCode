﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletController : MonoBehaviour
{
    public float BulletSpeed;
    public float LifeDuration;
    private float LifeTimer;

    //private PlayerController player;


    void Start()
    {
        LifeTimer = LifeDuration;
    }

    
    void Update()
    {
        Movement();
        SelfDestruct();
    }

    private void Movement()
    {
        transform.position += transform.forward * BulletSpeed * Time.deltaTime;       
    }

    public void SelfDestruct()
    {
        LifeTimer -= Time.deltaTime;
        if(LifeTimer <= 0f)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.transform.tag == "Enemy" || other.tag == "Enemy2" || other.tag == "Cactus"
            || other.tag == "Pinguino" || other.tag == "Robot" || other.tag == "Cebolla"
            || other.tag == "Kchup" || other.tag == "Macaco" || other.tag == "Malvavisco")
        {   
            Destroy(gameObject);
            Destroy(other.transform.gameObject);
        }

        if(other.CompareTag("HellShield"))
        {
            Destroy(this.gameObject);
        }
    }
}
