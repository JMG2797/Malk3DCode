﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MariposaController : MonoBehaviour
{
    //public GameObject P1;
    //public GameObject P2;
    public GameObject lazer;
    public GameObject socket;
    //public GameObject moveTo;
    public GameObject teleport;
    public Slider healthSlider;
    public GameObject marCanvas;
    public GameObject explosion;
    public Animator marAnim;
    Transform player;
    public float moveSpeed;
    public float health = 400f;
    //public float howClose;
    public float attackRate = 2f;
    private float attackCounter = 0f;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        marAnim = GetComponent<Animator>();
        teleport.SetActive(false);
        marCanvas.SetActive(true);

    }

    // Update is called once per frame
    void Update()
    {
        Movement();
        SetUI();
        if (attackCounter <= 0f)
        {
            Shoot();
            attackCounter = 1f / attackRate;
        }
        attackCounter -= Time.deltaTime;
        Death();
    }

    void Movement()
    {
        transform.LookAt(player);
        
        /*if(transform.position == P1.transform.position)
        {
            transform.position = Vector3.MoveTowards(transform.position, P2.transform.position, moveSpeed * Time.deltaTime);

        }
        if(transform.position == P2.transform.position)
        {
            transform.position = Vector3.MoveTowards(transform.position, P1.transform.position, moveSpeed * Time.deltaTime);
        }*/
    }

    void Shoot()
    {

        //marAnim.SetBool("Attacking", true);
        Instantiate (lazer, socket.transform.position, socket.transform.rotation);
    }

    void SetUI()
    {
        healthSlider.value = health;
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("PlayerBullet"))
        {
            health -= 30;
            SetUI();
        }
    }

    void Death()
    {
        if(health <=0)
        {
            Instantiate(explosion, transform.position, transform.rotation);
            Destroy(this.gameObject);
            moveSpeed = 0f;
            marAnim.SetBool("Dead", true);
            marCanvas.SetActive(false);
            teleport.SetActive(true);
        }
    }
}
