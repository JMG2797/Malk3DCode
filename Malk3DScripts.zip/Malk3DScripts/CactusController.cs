﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CactusController : MonoBehaviour
{
    public List<GameObject> Points;
    private int CurrentPoint;
    public float attackDistance;
    private float howClose;
    public Animator EnemyAnim;
    public GameObject explosion;
    public float radius;
    public float CactusSpeed = 6f;
    Transform player;
    private float attackCounter;
    public float attackRate;

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        EnemyAnim = GetComponent<Animator>();
    
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, Points[CurrentPoint].
                    transform.position, CactusSpeed * Time.deltaTime);

        if (transform.position == Points[CurrentPoint].transform.position)
        {
            EnemyAnim.SetBool("Attacking", false);
            CurrentPoint++;
            if (CurrentPoint >= Points.Count)
            {
                CurrentPoint = 0;
            }
            Vector3 NewDir = Points[CurrentPoint].transform.position - transform.position;
            NewDir.y = 0;

            if (NewDir != Vector3.zero)
            {
                transform.rotation = Quaternion.LookRotation(NewDir);
            }
        }

        attackCounter += Time.deltaTime;

        howClose = Vector3.Distance(transform.position, player.position);

        if(howClose <= attackDistance)
        {
            CactusSpeed = 0f;
            transform.LookAt(player);
            Attack();
        }
        else if( howClose >= attackDistance)
        {
            CactusSpeed = 6f;
        }

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.transform.parent.gameObject);
        }
    }

    void Attack()
    {
        if(attackCounter >= attackRate)
        {

            EnemyAnim.SetBool("Attacking", true);
            Instantiate(explosion, transform.position, transform.rotation);

            Collider[] colliders = Physics.OverlapSphere(transform.position, radius);
            foreach (Collider nearbyPlayer in colliders)
            {
                PlayerController malk = nearbyPlayer.GetComponent<PlayerController>();
                if (malk != null)
                {
                    //malk.playerHealth -= 20;
                    PlayerController.playerHealth -= 20;
                }
            }

            attackCounter = 0f;
            attackCounter += Time.deltaTime;

        }

    }

}
