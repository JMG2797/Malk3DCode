﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformController : MonoBehaviour
{
    public List<GameObject> Points;
    private int CurrentPoint;
    public float PlatformSpeed;
    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, Points[CurrentPoint].
            transform.position, PlatformSpeed * Time.deltaTime);

        if (transform.position == Points[CurrentPoint].transform.position)
        {
            CurrentPoint++;
            if (CurrentPoint >= Points.Count)
            {
                CurrentPoint = 0;
            }
        }
    }
}
