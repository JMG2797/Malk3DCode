﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class HeatController : MonoBehaviour
{
    //Floats Temp
    float CurrentTime = 0f;
    float StartingTime = 120f;

    private PlayerController player;

    //public Animation TempAnim;

    /*Floats Alpha
    float MaxAlpha = 190f;
    float StartAlpha = 0f;
    float CurrentAlpha;*/

    [Header("UI Elements")]
    public Slider TempSlider;
    public Image TempColor;

    void Start()
    {
        CurrentTime = StartingTime;
        StartColoring();
    }

    // Update is called once per frame
    void Update()
    {
        CurrentTime -= 1 * Time.deltaTime;
        //print(CurrentTime);
        TempSlider.value = CurrentTime;
        EndGame();
    }
    void StartColoring()
    {
        //TempAnim.Play();
    }
    void EndGame()
    {
        if (CurrentTime <= 0)
        {
            SceneManager.LoadScene(15);
        }

    }
}
