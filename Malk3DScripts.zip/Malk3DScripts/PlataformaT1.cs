﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlataformaT1 : MonoBehaviour
{

    Rigidbody rb;

    void Start()
    {
        rb.GetComponent<Rigidbody>();
        rb.isKinematic = false;
    }

    void Update()
    {

    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
            rb.isKinematic = true;
    }
}
