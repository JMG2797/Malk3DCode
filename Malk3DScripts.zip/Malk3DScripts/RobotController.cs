﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotController : MonoBehaviour
{
    public Animator EnemyAnim;
    public float ChargeSpeed;
    private Transform player;
    private float dist;
    public float howClose;
    public Rigidbody robotRB;
    public GameObject explosion;

    void Start()
    {
        robotRB = GetComponent<Rigidbody>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    { 
        dist = Vector3.Distance(player.position, transform.position);
        if(dist <= howClose)
        {
            EnemyAnim.SetBool("Attacking", true);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position, ChargeSpeed * Time.deltaTime);
        }

        else if (dist >= howClose)
        {
            EnemyAnim.SetBool("Attacking", false);
            transform.position = transform.position;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }

}
