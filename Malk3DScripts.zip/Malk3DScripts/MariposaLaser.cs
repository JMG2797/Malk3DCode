﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MariposaLaser : MonoBehaviour
{
    public float laserSpeed;
    public float lifeDuration;
    private float lifeCounter;
    private Transform player;
    private PlayerController pCont;
   // private Vector3 target;

    void Start()
    {
        lifeCounter = lifeDuration;
    }

    void Update()
    {
        transform.position += transform.forward * laserSpeed * Time.deltaTime;

        lifeCounter -= Time.deltaTime;
        if(lifeCounter <= 0)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {

        if(other.CompareTag("Shield"))
        {
            Destroy(this.gameObject);
        }
    }
}
