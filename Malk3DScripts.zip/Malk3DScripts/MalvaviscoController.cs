﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MalvaviscoController : MonoBehaviour
{
    public Rigidbody rb;
    public Animator malvaAnim;
    public GameObject homePoint;
    public GameObject explosion;
    public float speed;
    private Transform player;
    public float howClose;
    private float attackingRange;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        malvaAnim = GetComponent<Animator>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
        transform.position = homePoint.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        attackingRange = Vector3.Distance(transform.position, player.position);


        if (attackingRange <= howClose)
        {
            malvaAnim.SetFloat("Speed", 1);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position,
                speed * Time.deltaTime);
        }
        else
        {
            malvaAnim.SetFloat("Speed", 1);
            transform.LookAt(homePoint.transform.position);
            transform.position = Vector3.MoveTowards(transform.position, homePoint.transform.position,
                speed * Time.deltaTime);
        }

    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}
