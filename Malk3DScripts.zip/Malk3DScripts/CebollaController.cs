﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class CebollaController : MonoBehaviour
{
    public Animator EnemyAnim;
    private float dist;
    public float howClose;
    public float attackRange;
    public float explosionRadius;
    public AudioSource explosionSound;
    public AudioClip expEffect;
    public float volume = 1f;
    public float explosionForce;
    public float upforce = 1f;
    public GameObject explosion;
    private Transform player;

    public float CebollaSpeed;
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void Update()
    {
        EnemyAnim.SetFloat("Speed", Mathf.Abs
                  (Input.GetAxis("Horizontal") + Input.GetAxis("Vertical")));

        dist = Vector3.Distance(player.position, transform.position);

        if(dist <= howClose)
        {
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position,player.position,CebollaSpeed*Time.deltaTime);
            //GetComponent<Rigidbody>().AddForce(transform.forward * CebollaSpeed);

        }

        if(dist <= attackRange)
        {
            CebollaSpeed = 0f;
            Invoke("Explosion", 3f);
        }
        else
        {
            CebollaSpeed = 6f;
        }

    }

    void Explosion()
    {
        EnemyAnim.SetBool("Attack", true);

        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius);
        foreach (Collider hit in colliders)
        {
            PlayerController pCont = hit.GetComponent<PlayerController>();
            Rigidbody rb = hit.GetComponent<Rigidbody>();

            if(pCont != null)
            {
                //pCont.playerHealth -= 40;
                PlayerController.playerHealth -= 10;
            }
            if(rb != null)
            {
                rb.AddExplosionForce(explosionForce, transform.position, explosionRadius, upforce,
                    ForceMode.Impulse);
            }
        }
        explosionSound.PlayOneShot(expEffect, volume);
        Instantiate(explosion, transform.position, transform.rotation);
        Destroy(this.transform.parent.gameObject);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }

}
