﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VacaController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float chargeSpeed = 15f;
    public float health = 400f;
    public Slider healthSlider;
    public GameObject canvas;
    public GameObject teleport;
    public GameObject bullet;
    public GameObject socket;
    public GameObject explosion;
    public float attackRate = 2f;
    private float attackCounter;
    public float chargeDistance = 7;
    private float dist;
    public Animator vacaAnim;
    Transform player;
    public Rigidbody vacaRigidbody;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        vacaAnim = GetComponent<Animator>();
        vacaRigidbody = GetComponent<Rigidbody>();
        canvas.SetActive(true);
        teleport.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        dist = Vector3.Distance(transform.position, player.position);

        attackCounter -= Time.deltaTime;

        if(dist >= chargeDistance)
        {
            vacaAnim.SetBool("Attacking", false);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position, moveSpeed * Time.deltaTime);
        }

        else if(dist <= chargeDistance)
        {
            vacaAnim.SetBool("Attacking", true);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position, chargeSpeed * Time.deltaTime);
        }
        if (health <= 0)
        {
            Destroy(this.gameObject);
            canvas.SetActive(false);
            teleport.SetActive(true);
            Instantiate(explosion, transform.position, transform.rotation);
        }
        SetUI();
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Shield"))
        {
            health -= 25;
            SetUI();


        }

        if(other.CompareTag("PlayerBullet"))
        {
            health -= 20;
            SetUI();
        }
    }

    void SetUI()
    {
        healthSlider.value = health;
    }
}
