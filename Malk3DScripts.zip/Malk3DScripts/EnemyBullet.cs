﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour
{
    public float EnemyBulletSpeed;
    public float LifeDuration;
    private float LifeCounter;
    private Transform player;
    private Vector3 target;
    
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        //LifeDuration = LifeCounter;
        target = new Vector3(player.position.x, 1, player.position.z);
    }

    void Update()
    {
        Movement();
        SelfDestruct();
    }

    public void Movement()
    {
        //transform.position = Vector3.MoveTowards(transform.position, target,
        //EnemyBulletSpeed * Time.deltaTime);

        //transform.Translate(target * EnemyBulletSpeed * Time.deltaTime);
        transform.position += transform.forward * EnemyBulletSpeed * Time.deltaTime;
    }

    public void SelfDestruct()
    {
        LifeDuration -= Time.deltaTime;
        if (LifeCounter <= 5f)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
            
        }
    }
}
