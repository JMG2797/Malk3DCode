﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MuelaController : MonoBehaviour
{
    public float moveSpeed;
    public float attackSpeed;
    public float health = 350f;
    public float howClose = 5f;
    private float attackSDistance;
    private float swordRange = 3f;
    public Rigidbody muelaRb;
    public Animator muelaAnim;
    public Slider healthSlider;
    public GameObject Canvas;
    public GameObject teleport;
    public GameObject explosion;
    Transform player;



    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        muelaAnim = GetComponent<Animator>();
        muelaRb = GetComponent<Rigidbody>();
        teleport.SetActive(false);
        Canvas.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        SetUI();

        attackSDistance = Vector3.Distance(transform.position, player.position);

        if (attackSDistance > howClose)
        {
            muelaAnim.SetBool("Attacking", false);
            transform.position = Vector3.MoveTowards(transform.position, player.position, 9f * Time.deltaTime);
            Vector3 NewDir = player.position - transform.position;
            NewDir.y = 0;
            if (NewDir != Vector3.zero)
            {
                transform.rotation = Quaternion.LookRotation(NewDir);
            }
        }

        else if(attackSDistance < howClose)
        {
            muelaAnim.SetBool("Attacking", true);
            if(howClose < swordRange)
            {
                PlayerController.playerHealth -= 15;
            }
        }

        if (health <= 0)
        {
            Instantiate(explosion, transform.position, transform.rotation);
            Destroy(this.gameObject);
            Canvas.SetActive(false);
            teleport.SetActive(true);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Shield"))
        {
            health -= 25;
        }

        if (other.CompareTag("PlayerBullet"))
        {
            health -= 15;
        }
    }

    void SetUI()
    {
        healthSlider.value = health;
    }
}
