﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
public class AgilityPowerUp : MonoBehaviour
{
    public float SpeedMultiplier = 2f;
    public float JumpMultiplier = 2f;
    public float duration = 6f;
    public GameObject Player;
    public GameObject AgilityPowerUpEffect;
    public AudioSource PUAS;
    public AudioClip PUAC;
    public float volume;


    void OnTriggerEnter(Collider ObjCollision)
    {
        if (ObjCollision.tag == "Player")
        {
            StartCoroutine(PickUp(ObjCollision));
        }
    }

    IEnumerator PickUp(Collider Player)
    {
        Instantiate(AgilityPowerUpEffect, transform.position, transform.rotation);
        PUAS.PlayOneShot(PUAC, volume);
        PlayerController Control = Player.GetComponent<PlayerController>();
        Control.playerJumpSpeed *= JumpMultiplier;
        Control.playerSpeed *= SpeedMultiplier;
        GetComponent<MeshRenderer>().enabled = false;
        GetComponent<Collider>().enabled = false;

        yield return new WaitForSeconds(5f);
        Control.playerJumpSpeed /= JumpMultiplier;
        Control.playerSpeed /= SpeedMultiplier;

        Destroy(gameObject);
        Debug.Log("Power Up Recogido");
    }
}
