﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Audio;
public class ReyGorgonzollaController : MonoBehaviour
{
    public float bossHealth = 700;
    public float StoppingDistance;
    public float RetreatDistance;
    public float timeBtwShots;
    private float StartTimeBtwShots;
    //public float Speed;
    public GameObject explosion;
    public Slider BossHealth;
    public Animator BossAnim;
    public bool SecondPhase;
    public GameObject BossUI;
    public PlayerController player;
    private Vector3 BossMoveDir;
    public GameObject Target;
    public GameObject Socket;
    // public float playerDist;
    public GameObject EnemyBullet;
    public GameObject EndPoint;
    private float howClose;
    public float attackDist;
    void Start()
    {
        SecondPhase = false;
        timeBtwShots = StartTimeBtwShots;
        EndPoint.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    { 
        SetUI();
        Movement();
        Phase2();

        howClose = Vector3.Distance(transform.position, Target.transform.position);

        if(howClose<= attackDist)
        {
            BossAnim.SetBool("Attacking", true);
        }

    }


    public void OnTriggerEnter(Collider ObjCollision)
    {
        if (ObjCollision.tag == "PlayerBullet")
        {
            bossHealth = bossHealth - 15;
            if (bossHealth <= 0)
            {
                Instantiate(explosion, transform.position, transform.rotation);
                Destroy(this.gameObject);
                bossHealth = 0;
                SetUI();
                BossUI.SetActive(false);
                //SceneManager.LoadScene(4);
                EndPoint.SetActive(true);
            }
        }

        if(ObjCollision.CompareTag("Player"))
        {
            bossHealth += 15;
            SetUI();
        }

        if (ObjCollision.tag == "Deathzone")
        {
            //SceneManager.LoadScene(4);
            Destroy(this.gameObject);
            bossHealth = 0;
            SetUI();
            BossUI.SetActive(false);
            EndPoint.SetActive(true);
        }

        if (ObjCollision.tag == "Shield")
        {
            bossHealth = bossHealth - 25;
            player.playerShield.SetActive(false);
            SetUI();
        }
    }

    void Movement()
    {
        BossAnim.SetBool("Attacking", false);

        transform.position = Vector3.MoveTowards(transform.position, Target.transform.position,
            9f * Time.deltaTime);

        Vector3 NewDir = Target.transform.position - transform.position;
        NewDir.y = 0;
        if (NewDir != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(NewDir);
        }


    }

    public void SetUI()
    {
        BossHealth.value = bossHealth;
    }

    public void Phase2()
    {
        if (bossHealth <= 350)
        {
            SecondPhase = true;
            if (SecondPhase == true)
            {
                bossHealth = bossHealth + 5 * Time.deltaTime;
                SetUI();
            }
        }
        else
        {
            SecondPhase = false;
        }


    }
}
