﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MacacoController : MonoBehaviour
{

    public GameObject explosion;
    public GameObject bullet;
    public GameObject socket;
    public float attackRate = 2f;
    private float attackCounter;
    public float attackDistance = 7;
    private float dist;
    public Animator anim;
    Transform player;
    public Rigidbody rb;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        dist = Vector3.Distance(transform.position, player.position);

        if (dist >= attackDistance)
        {
            transform.position = transform.position;
        }

        else if (dist <= attackDistance)
        {
            transform.LookAt(player);
            if(attackCounter <= 0f)
            {
                Instantiate(bullet, socket.transform.position, socket.transform.rotation);
                attackCounter = 1f / attackRate;
            }
            
        }

        attackCounter -= Time.deltaTime;
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Shield"))
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}
