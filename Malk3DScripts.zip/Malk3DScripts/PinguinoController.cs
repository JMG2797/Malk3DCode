﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PinguinoController : MonoBehaviour
{
    public Rigidbody piguinoRB;
    public Animator pinguinoAnim;
    public GameObject homePoint;
    public float pinguinoSpeed;
    private Transform player;
    public float howClose;
    private float attackingRange;
    public GameObject explosion;


    // Start is called before the first frame update
    void Start()
    {
        piguinoRB = GetComponent<Rigidbody>();
        pinguinoAnim = GetComponent<Animator>();
        player = GameObject.FindGameObjectWithTag("Player").transform;
        transform.position = homePoint.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        attackingRange = Vector3.Distance(transform.position, player.position);

        
        if(attackingRange <= howClose)
        {
            pinguinoAnim.SetFloat("Speed", 1);
            transform.LookAt(player);
            transform.position = Vector3.MoveTowards(transform.position, player.position,
                pinguinoSpeed * Time.deltaTime);
        }
        else
        {
            pinguinoAnim.SetFloat("Speed", 0);
            transform.LookAt(homePoint.transform.position);
            transform.position = Vector3.MoveTowards(transform.position, homePoint.transform.position,
                pinguinoSpeed * Time.deltaTime);
        }

    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Shield")
        {
            Destroy(this.gameObject);
        }
        if (other.tag == "PlayerBullet")
        {
            Destroy(this.gameObject);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }
}
