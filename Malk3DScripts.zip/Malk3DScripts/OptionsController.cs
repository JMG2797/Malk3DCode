﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class OptionsController : MonoBehaviour
{
    public AudioMixer audioMixer;
    public GameObject SettingsPanel;
    public GameObject ControlsPanel;
    public GameObject CreditsPanel;

    public void SetVolume(float volume)
    {
        Debug.Log(volume); //Para ver el nivel del volumen
        audioMixer.SetFloat("volume", volume);
    }

    public void SetQuality (int qualityindex)
    {
        QualitySettings.SetQualityLevel(qualityindex);
    }

    public void SetFullScreen (bool isFullScreen)
    {
        Debug.Log("FullScreen Changed");
        Screen.fullScreen = isFullScreen;
    }

    public void ActivateControlScene()
    {
        SettingsPanel.SetActive(false);
        ControlsPanel.SetActive(true);
    }

    public void ActivateSettingsPanel()
    {
        ControlsPanel.SetActive(false);
        CreditsPanel.SetActive(false);
        SettingsPanel.SetActive(true);
    }

    public void ActiveVideoPanel()
    {
        SettingsPanel.SetActive(false);
        CreditsPanel.SetActive(true);
    }

    public void BackToMainMenu()
    {
        SceneManager.LoadScene(1);
    }
}
